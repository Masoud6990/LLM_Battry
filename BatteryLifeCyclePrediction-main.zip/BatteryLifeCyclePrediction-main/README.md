# BatteryLifeCyclePrediction

### Original Dataset link:
https://data.matr.io/1/projects/5c48dd2bc625d700019f3204

### Pickled Data:
https://drive.google.com/drive/folders/19jUR_RfVcwIhNvyfWe09xgeZxlogKZR7?usp=sharing

### Processed CSVs of each cell 
https://drive.google.com/drive/folders/14QldKKSsGfrhbbu5oPagKPyunM9kdpxV?usp=drive_link
